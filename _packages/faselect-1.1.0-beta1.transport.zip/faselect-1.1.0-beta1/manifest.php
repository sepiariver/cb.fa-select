<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '96c5722c01371d8cfddb8bde5e6fdd05',
      'native_key' => 'faselect',
      'filename' => 'modNamespace/40da338656c0aa50e07d1adae1eb7ac2.vehicle',
      'namespace' => 'faselect',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43ec6fc037707248570b4ca7e5d86d84',
      'native_key' => 'faselect.faselect.output_path',
      'filename' => 'modSystemSetting/07b6bc13742e38f35465e17d2e0fc885.vehicle',
      'namespace' => 'faselect',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f676ca4922f0d4f9a42714e23c497c1',
      'native_key' => 'faselect.faselect.output_filename',
      'filename' => 'modSystemSetting/1ea038d68d7514d11d261b1a2f9d07a4.vehicle',
      'namespace' => 'faselect',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a7c98ca87359539e003002fe9cbacd1a',
      'native_key' => NULL,
      'filename' => 'modCategory/212617034d5ebd09b3db41ead9b30314.vehicle',
      'namespace' => 'faselect',
    ),
  ),
);