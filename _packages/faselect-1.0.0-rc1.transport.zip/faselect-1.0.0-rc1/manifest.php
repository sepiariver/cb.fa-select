<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3dd77dcbf86d3f074a219e4704fc75fc',
      'native_key' => 'faselect',
      'filename' => 'modNamespace/971365794ce8075e73b15d75adde1467.vehicle',
      'namespace' => 'faselect',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38fbd9d381f11ca540f5c649a0bf21ab',
      'native_key' => 'faselect.faselect.output_path',
      'filename' => 'modSystemSetting/e3b9af2489b2f54ceec20a592d82b321.vehicle',
      'namespace' => 'faselect',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b77886ad97d9322c373f29cc7b6f7e7b',
      'native_key' => 'faselect.faselect.output_filename',
      'filename' => 'modSystemSetting/84308b28b591467b9563336ed60ea979.vehicle',
      'namespace' => 'faselect',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '337e16fce95e912c15c9685e5c2d395f',
      'native_key' => NULL,
      'filename' => 'modCategory/28f9dbf73436bde790bcdcc53fabd47a.vehicle',
      'namespace' => 'faselect',
    ),
  ),
);