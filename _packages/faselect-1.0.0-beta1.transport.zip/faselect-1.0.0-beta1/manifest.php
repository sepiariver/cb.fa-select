<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9161c0f32d22aa6f85d75323e4e963fa',
      'native_key' => 'faselect',
      'filename' => 'modNamespace/0bb2d5e971c8cce99a0e4ed8c80a4724.vehicle',
      'namespace' => 'faselect',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6263a45c3fd73dcc675bf68b65dcc48e',
      'native_key' => 'faselect.faselect.output_path',
      'filename' => 'modSystemSetting/d1fa934a6dc0a012a375e2bcf1afac70.vehicle',
      'namespace' => 'faselect',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '195c28a5c306c857e4c20e0e5cd63090',
      'native_key' => 'faselect.faselect.output_filename',
      'filename' => 'modSystemSetting/d0b0863d93313ad1c9bba475733c22b5.vehicle',
      'namespace' => 'faselect',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ca9f95a18ae9af7f391e4d19163f4a1c',
      'native_key' => NULL,
      'filename' => 'modCategory/f483480c8320df6f4bc0d617e68923b2.vehicle',
      'namespace' => 'faselect',
    ),
  ),
);